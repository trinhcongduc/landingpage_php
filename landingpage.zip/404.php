<?php include('inc/header.php');?>
  <div class="jumbotron text-xs-center">
    <div class="container text-center">
      <h1 class="display-1">404</h1>
      <p class="lead">Không tìm thấy trang bạn yêu cầu</p>
      <p class="lead">
        <a class="btn btn-primary btn-sm" href="<?php echo $base_url?>" role="button">Trở về trang chủ</a>
      </p>
    </div>

  </div>

<?php include('inc/footer.php');?>
