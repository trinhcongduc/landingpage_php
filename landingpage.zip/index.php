<!--Content page-->
<?php include('inc/header.php');?>
<?php

$lang_default == "vi"?include('inc/content-home-vi.php'):include('inc/content-home-en.php')

?>
<?php include('inc/footer.php');?>
