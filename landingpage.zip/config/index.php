<?php

require_once "main_config.php";
require_once "mail.php";
require_once "database.php";
require_once "language.php";