<?php
/**
 * Config database
 */


$hostname="localhost";
$userhost = "root";
$passhost = "";
$dbname = "vemba";
$tablename  = "contacts";