<?php
/**
 * Config Global
 */
$base_url = "http://localhost:8888/landingpage";

/**
 * Config Seo
 */
$title = "Title here";
$description = "Description";
$keywords = "Keyword";
$author = "Author";

