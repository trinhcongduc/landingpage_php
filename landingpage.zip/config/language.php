<?php

$lang_default = "vi";

